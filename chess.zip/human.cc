#include "human.h"
#include "player.h"
#include "info.h"

Human::Human(Colour colour, Game * game): Player{0, colour, game} {}

void Human::goMove(Coor & scr, Coor & dest) {}
